create definer = developer@localhost event sess_cleanup on schedule
    every '15' MINUTE
        starts '2019-12-07 19:34:35'
    enable
    do
    DELETE FROM `sessions` WHERE sid IN (SELECT temp.sid FROM (SELECT `sid` FROM `sessions` WHERE `expires` > 0 AND `expires` < UNIX_TIMESTAMP()) AS temp);

